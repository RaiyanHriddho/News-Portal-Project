Assalamu-Alaikum Everyone,

I am Nirob Hasan And I'm a Web Developer by profession. With experience and expertise spanning around 7 years, in the Digital space.

Good amount of experience in development of web applications using PHP, Frameworks, JavaScript Library’s, CMS, API’s, Reporting tools and Payment Gateways. Skilled in digital technology innovation's, brand building and all phases of the Web development lifecycle with an expert in translating business requirements into technical solutions and fanatical about quality, usability, security, and scalability. Dealing with and resolving problems and issues which arise.

Thank you.

Youtube Link: https://youtube.com/nirobhasan

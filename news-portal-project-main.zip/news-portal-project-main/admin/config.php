<?php 

$connection = mysqli_connect('localhost','root','','live_news_project') or die("Not Connected". mysqli_error());

?>